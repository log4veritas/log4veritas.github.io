from collections import Counter

string = ('''xultpaajcxitltlxaarpjhtiwtgxktghi
dhipxciwtvgtpilpitghlxiwiwtxgqaddsv''')

x = list(string)

# create a dictionary counting character frequency
c = Counter(x)

# remove spaces and new line characters etc.
del c[' '], c['\n'], c['.'], c[',']

# count all characters
n_letters1 = len(x) - x.count('\n') - x.count(' ')
n_letters = n_letters1 - x.count(',') - x.count('.')
print('Total number of letters:', n_letters)

# normalize the frequencies into a distribution
y = {k: v / n_letters for k, v in c.items()}

# sort by value. note that this is now a list of tuples
d = sorted(y.items(), key=lambda xd: xd[1], reverse=True)

# make a table for easy reading
print("{:<8} {:<15}".format('Letter', 'Freq. Dist.'))
for k, v in d:
    print("{:<8} {:<15}".format(k, v))

# replace characters according to frequency only
# define ordered strings of letter frequency
# eng_letter_freq = 'abcdefghijklmnopqrstuvwxyz'
eng_letter_freq = 'etaoinshrdlcumwfgypbvkjxqz'
ciph_freq = ''
for i, j in d:
    ciph_freq = ciph_freq + i
if len(ciph_freq) < 26:
    ciph_freq = ciph_freq + '.' * (26 - len(ciph_freq))

# use the strings to replace characters
cypher_map = str.maketrans(ciph_freq, eng_letter_freq)
semi_decrypted = string.translate(cypher_map)
print(semi_decrypted)
