library(Rlab)

N = 1000
p = 0.5

# Generate Bernoulli random variables
x <- rbern(N, prob = p)

# Count the number of heads
sum = sum(x)

# Runs of heads
z = 0
w <- c()

for (y in x){
  if (y == 1){
    z = z + 1
    w <- c(w,z)
  } 
  else {
    z = 0
    w <- c(w,z)
  }
}

# Print results
print(paste("Number of heads =", sum))
print(paste("Longest run of heads =", max(w)))
print(paste("Expected longest run =", 
            format(round(log2(N)-1, 2), nsmall = 2)))

if (N < 50){
  print("Bernoulli sequence")
  print(x)
  print("Runs of heads sequence")
  print(w)
}

