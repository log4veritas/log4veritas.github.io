# There are four Bernoulli related functions in R
# We look at all four in this project

library(Rlab)

# dbern() measures the density function
# Syntax: dbern(x, prob, log = FALSE)
# Where x is a vector of quantities
# prob is the probability of success of each trial
# log: if TRUE, probabilities are given as log(p)

x <- seq(0, 5, by = 1)
y <- dbern(x, prob = 0.6)  
plot(y, type = "o", main = "Bern PDF")
print(y)

# pbern() measures the cumulative distribution
# Syntax: pbern(q, prob, lower.tail = TRUE, log.p = FALSE)
# Where q is a vector on quantiles
# prob is the probability of success
# lower.tail: determines greater than or less than
# log.p: if true, probabilities are given as log(p)

x <- seq(0, 5, by = 1)
y <- pbern(x, prob = 0.6)  
plot(y, type = "o", main = "Bern CDF")
print(y)

# qbern() gives the quantile function
# Syntax: qbern(p, prob, lower.tail = TRUE, log.p = FALSE)
# Where p is a vector of probabilities
# prob is the probability of success on each trial
# lower.tail: determines greater than or less than
# log.p: if true, probabilities are given as log(p)

x <- seq(0, 1, by = 0.2)
y <- qbern(x, prob = 0.5,lower.tail = TRUE, log.p = FALSE)  
plot(y, type = "o", main = "Bern Quantiles")
print(y)

# rbern() is used to generate a vector of random Bernoulli RVs
# Syntax: rbern(n, prob)
# Where n is the number of observations to generate
# prob is the probability of success

x <- rbern(10, prob=0.5)
print(x)


