
# this script will compute the discrete time probability of ruin for
# an insurance company, where the number of claims per period is an
# i.i.d binomial random variable

binom_ruin_prob <- function(n, p, income, claim, surplus_0, p_thresh){
  
  # DEFINITION OF INPUT VARIABLES
  # n is the number of insured entities
  # p is the probability an insured entity generates a claim
  # income is the premium income per period (from all insured entities)
  # claim is the payout per claim
  # surplus_0 is the initial surplus
  
  # OUTPUT
  # the output is the scalar probability of ruin (between 0 and 1)
  
  # IMPORTANT TECHNICAL CONDITIONS
  # income and claims need to be scaled such that income is 1 per period
  # in the case income is not initially 1, it must divide claim evenly
  # in other words scaled claim amounts must be on the non-negative integers
  # expected value of the first period's claim amount is less than income
  # the number of claims in a period are binomial distributed
  
  #---------------------------------------------------------------------#
  
  # optional arguments
  if (missing(p_thresh)){p_thresh <- 0.01}
  
  # scale premium income and claims so that income is 1 per period
  # this is just how we use the model is constructed
  claim <- claim/income
  income <- 1
  
  # return errors if technical conditions are not satisfied
  if (n*p*claim >= 1){stop("Expected value of first period claim 
                            is greater than 1. Ruin is guaranteed.
                           Review technical conditions")}
  if (claim %% income != 0)
  {stop("Claim is not an integral multiple of income")}
  
  # generate the NUMBER of claims distribution...
  # for simplicity when p_claim gets really small (line 50), we attach the 
  # inverse cumulative probability (greater than or equal to the last index1) 
  # at the end of dist to make it a true distribution (sum to 1)
  n_clm_dist <- c()
  p_claim <- 1
  index1 <- 0
  
  while (p_claim > p_thresh){ # make p_claim threshold an optional parameter
    p_claim <- dbinom(index1, n, p)
    n_clm_dist <- append(n_clm_dist, p_claim)
    index1 <- index1 + 1
  }
  n_clm_dist <- append(n_clm_dist, 1 - sum(n_clm_dist)) # see line 43-45
  
  # now transform this to be the VALUE of claims distribution
  payout_dist <- c()
  for (index2 in 0:max((claim*length(n_clm_dist)-1),surplus_0))  {
    if ((index2 %% claim == 0) & (index2 < (claim*length(n_clm_dist)-1)))
      {payout_dist <- append(payout_dist, n_clm_dist[(index2/claim)+1])}
    else {payout_dist <- append(payout_dist, 0)}
  }
  
  # then the cumulative distribution
  cumulative <- cumsum(payout_dist)
  
  # the last intermediary vector, the inverse cumulative distribution
  inv_cumulative <- 1 - cumulative
  
  # finally, the hard part: compute the ruin probability vector
  # the formula is different if surplus_0 == 0, so do that first
  if (surplus_0 == 0){psi <- n*p*claim
    surplus_0 <- 1
  } else { # now for surplus_0 greater than 0
    # start with an intermediary vector for the second sum in the formula
    sum2 <- c()
    for (index3 in 1:surplus_0){
      if (is.na(inv_cumulative[index3 + 1])){
        sum2 <- append(sum2, 0)
      } else{ sum2 <- append(sum2, sum(inv_cumulative[(index3 + 1): 
                                          length(inv_cumulative)]))
      }
    }
    
    # need to compute psi for every surplus level less than surplus_0
    # because the formula is recursive.
    psi <- c(sum2[1]/cumulative[1])
    for (index4 in 2:surplus_0){
      tranche <- rev(inv_cumulative[2:(index4)])
      dot <- sum(tranche*psi[1:length(psi)])
      psi <- append(psi, (dot + sum2[index4])/cumulative[1])
    }
    }
  
  return(psi[surplus_0])
}

print(binom_ruin_prob(100, 0.001, 1, 5, 7))
