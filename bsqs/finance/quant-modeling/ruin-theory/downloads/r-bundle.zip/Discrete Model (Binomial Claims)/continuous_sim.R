# first define helper function: the poisson process

pois_process <- function(s, lambda){
  process <- c(rexp(1, rate = lambda))
  arrivals <- c()
  while(process[length(process)] < s){
    process <- append(process, process[length(process)] 
                      + rexp(1, rate = lambda))
  }  
  process <- process[1:(length(process)-1)]
  arrivals <- c(1:length(process))
  
  return(matrix(c(arrivals, process), ncol = 2, byrow = F))
}


# claims are exponentially distributed

agg_claim <- function(endtime){
  pois <- length(pois_process(endtime, lambda)[,1])
  if(pois == 0){claim_series <- c(0)
  } else {
    claim_series <- rexp(pois, lambda)
    claim_series <- cumsum(claim_series)
    }
  return(claim_series)
}


lambda = 1
n = 100
p = 0.001

print(agg_claim(10))






# cont_surplus_sim <- function(n, p, time, income, claim, lambda, surplus_0){
 
# }