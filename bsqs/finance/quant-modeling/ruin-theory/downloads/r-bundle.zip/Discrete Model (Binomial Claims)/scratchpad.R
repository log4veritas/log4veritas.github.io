# start by defining the poisson process

pois_process <- function(s, lambda){
  process <- c(rexp(1, rate = lambda))
  arrivals <- c()
  while(process[length(process)] < s){
    process <- append(process, process[length(process)] 
                      + rexp(1, rate = lambda))
  }  
  process <- process[1:(length(process)-1)]
  arrivals <- c(1:length(process))
  
  return(matrix(c(arrivals, process), ncol = 2, byrow = F))
}
