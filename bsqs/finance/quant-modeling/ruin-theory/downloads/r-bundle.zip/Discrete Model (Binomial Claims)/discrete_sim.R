
# this function simulated the discrete time surplus process

discrete_binom_sim <- function(n, p, time, income, claim, surplus_0){
  
  # DEFINITION OF INPUT VARIABLES
  # n is the number of insured entities
  # p is the probability an insured entity generates a claim
  # time is the number of periods to simulate
  # income is the premium income per period (from all insured entities)
  # claim is the payout per claim (constant)
  # surplus_0 is the initial surplus
  
  # OUTPUT
  # the output is a time series of the surplus process
  # it is a vector where entries give the surplus value at the 
  # end of each period
  
  # IMPORTANT TECHNICAL CONDITIONS

  #---------------------------------------------------------------------#
  
  # scale premium income and claims so that income is 1 per period
  # this is just how we use the model is constructed
  claim <- claim/income
  income <- 1
  
  claim_process <- claim*rbinom(time, n, p)
  process <- c(surplus_0)
  
  for (index in 1:time){
    process <- append(process, process[length(process)] + 1 
                      - claim_process[index])
    if (process[length(process)] <= 0){break}
  }
  
  process <- append(process, rep(process[length(process)], 
                                 time - index))

 return(process) 
}


 plot(discrete_binom_sim(100, 0.001, 50, 1, 4, 2), type = "l",
      xlab = "Time", ylab = "Surplus", main = "The Discrete Surplus Process")

